def test_put_get():
    from hash_table import HashTable
    t = HashTable()
    t.put("a", 1)
    assert t.get("a") == 1
